var app=getApp()
Page({
  data: {
    //模拟假数据
    seats: [
      { num: "7-8", userInfo: { uid: 15998983598, name: '阎阎' } },
      { num: "8-9", userInfo: { uid: 15998983598, name: '阎阎' } },
      { num: "9-10", userInfo: { uid: 13998983598, name: '花花' } },
      { num: "10-11", userInfo:null},
      { num: "11-12", userInfo: { uid: 18998983598, name: '仙球' } },
      { num: "12-13", userInfo: { uid: 19998983598, name: '亮亮' } },
      { num: "13-14", userInfo: null },
      { num: "14-15", userInfo: null },
      { num: "15-16", userInfo: null },
      { num: "16-17", userInfo: null },
      { num: "17-18", userInfo: null },
      { num: "18-19", userInfo: { uid: 13998983598, name: '花花' } },
      { num: "19-20", userInfo: null },
      { num: "20-21", userInfo: null },
      { num: "21-22", userInfo: null },
      { num: "22-23", userInfo: null }
    ],
    myselectSite:[]
  },

  xiayibubtn:function(options){
    wx.navigateTo({
      url: '../shenfenxinxi/shenfenxinxi',
    })
     var ceshishuju = this.data.myselectSite
    // ["7-8","8-9"]//这个到时候换成myselectsite！
     var shijianbiaoji= []
    wx.cloud.init({
      env: 'test-92ce45'
    });
    const db = wx.cloud.database();
    const _ = db.command;

     db.collection('hello').where({
      _id: "b1a52c595fc7505a00cd385c24e5d869",
      _openid: "ohe065GnE45k-qKNMkD1e1LCQsrY",
    }).get({
      success: function (res) {
      for(let j = 0;j < ceshishuju.length;j++)
      {
        for (let i = 0; i < 17; i++) 
        {
          if(ceshishuju[j] == res.data[0].rentInfo[i].time)
             shijianbiaoji[j] = i
          // console.log(res.data[0].rentInfo[i].time)
          // console.log(ceshishuju)
        }
      }
for(let i=0;i<shijianbiaoji.length;i++)
{
        if(shijianbiaoji[i]==0){
        db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              0:{
                isRent:true
              }
            }
          }
        })
      }
        else if(shijianbiaoji[i]==1)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              1:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==2)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              2:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==3)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              3:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==4)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              4:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==5)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              5:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==6)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              6:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==7)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              7:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==8)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              8:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==9)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              9:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==10)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              10:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==11)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              11:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==12)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              12:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==13)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              13:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==14)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              14:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==15)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              15:{
                isRent:true
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==16)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              16:{
                isRent:true
              }
            }
          }
        })}
      }
    }
    })
  },
//测试用的
    //  db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
    //         // data 传入需要局部更新的数据
    //         data: {
    //           rentInfo:{
    //             0:{
    //               isRent:false
    //             }
    //           }
    //         }
    //       })

   


   
    //     db.collection('hello').doc(b1a52c595fc7505a00cd385c24e5d869).update({
    //         // data 传入需要局部更新的数据
    //         data: {
    //           rentInfo:{
    //             0:{
    //               isRent:false
    //             }
    //           }
    //         }
    //       })
    //   }
    // })

    // const db = wx.cloud.database();
    // db.collection('hello').where({//三处数据库集合名字
    //   rentInfo:
    // }).get({
    //   success: function (res) {
    //     console.log(time)
    //     var id = res.data[0]._id
    //     console.log(res.data)
    //     if (res.data.length == 1)
    //     {
    //       db.collection('hello').doc(id).update({
    //         // data 传入需要局部更新的数据
    //         data: {
    //          isRent: true
    //         }
    //       })
    //     }
    //     }
    //   }
    // )


  //重组数据-分为四个一组
  reSetData(dataList,num) {
    let arr = [];
    let len = dataList.length;
    for (let i = 0; i < len; i += num) {
      arr.push(dataList.slice(i, i + num));
    }
    return arr;
  },

  //移除选择的座位
  remove (arr,val) {
    var index = arr.indexOf(val);
    if (index > -1) {
      arr.splice(index, 1);
    }
  },

  //选择座位
  selctedSite(e){
    let { myselectSite } = this.data;
    const param = e.target.dataset;
    const { num, used } = param;
    if (!used) { return  false};
    if (myselectSite.indexOf(num)===-1){
      myselectSite.push(num)
    }else{
      this.remove(myselectSite,num)
    }
    this.setData({ myselectSite })
    app.globalData.myselectSite=myselectSite
  },

  onLoad: function (options) {
    const that = this
    wx.cloud.init({
      env: 'test-92ce45'
    });
    const db = wx.cloud.database();
    db.collection('hello').where({
      _id: "b1a52c595fc7505a00cd385c24e5d869",
      _openid: "ohe065GnE45k-qKNMkD1e1LCQsrY"
    }).get({
      success: function (res) {
        const rentInfo = res.data[0].rentInfo
        const formatedRentInfo = rentInfo.map(timeInfo => {
          const { time, rentPeople, isRent } = timeInfo
          timeInfo.num = time
          timeInfo.userInfo = isRent ? rentPeople : null
          return timeInfo
        })
        that.setData({
          seats: formatedRentInfo
        })
        let { seats } = that.data;
        let temp = that.reSetData(seats,4)
        that.setData({ seats: temp })
        console.log(that.data.seats)
      }
    })
  }
})