// pages/test/test.js
//点击跳转！！！！
Page({
  logbtn:function(options){
    wx.navigateTo({
      url: '../logs/logs',
    })
  },
  jumpbtn:function(options){
    wx.navigateTo({url: '../new/new'})

    //navigateto可以实现回退功能！！但不能跳转到tabbar组件
},

data: {
  currentIndex:0, // 滑动组件：顶部自定义导航栏，切换的标准
},
swiperNav:function(e){
  this.setData({currentIndex:e.currentTarget.id});
}

})