// pages/chezhupaihao/chezhupaihao.js
Page({
  data: {
    isKeyboard: !1, //控制键盘外部显示
    isNumberKB: !1, //键盘切换
    tapNum: !1, //控制数字
    bottomNum: !1,//控制港澳使学
    disableKey: "1234567890港澳学使",
    keyboardNumber: "1234567890ABCDEFGHJKLMNPQRSTUVWXYZ港澳学使",
    keyboard1: "京沪粤津冀晋蒙辽吉黑苏浙皖闽赣鲁豫鄂湘桂琼渝川贵云藏陕甘宁青新港澳台使无",
    inputPlates: {
      index0: "粤",
      index1: "B",
      index2: "",
      index3: "",
      index4: "",
      index5: "",
      index6: "",
      index7: ""
    },
    inputOnFocusIndex: "",
    isnewNw:'+\n新能源',
    isbtns:true,
    plate:"",
    flag: false
  },
  onLoad: function () {
    this.initPlate(); //初始化获取车牌
  },
  initPlate:function(){
  let n = this.data.inputPlates.index0 + this.data.inputPlates.index1 + this.data.inputPlates.index2 +  this.data.inputPlates.index3    +      this.data.inputPlates.index4 + this.data.inputPlates.index5 + this.data.inputPlates.index6 + this.data.inputPlates.index7;
    let plates = this.data.inputPlates;
    let len;
    if (plates.index0 == '' || plates.index1 == '' || plates.index2 == '' || plates.index3 == '' || plates.index4 == '' || plates.index5 == '' || plates.index6 == ''){
      len = true;
    }else{
      len = false
    }
    this.setData({
      plate: n, //更新车牌
      isbtns: len //更新按钮状态
    });
  },
  inputClick: function (t) { //点击输入选项
    var that = this;
    that.setData({
      inputOnFocusIndex: t.target.dataset.id,
      isKeyboard: !0
    })
    "0" == this.data.inputOnFocusIndex ? that.setData({
      tapNum: !1,
      isNumberKB: !1,
      bottomNum: !1
    }) : "1" == this.data.inputOnFocusIndex ? that.setData({
      tapNum: !1,
      isNumberKB: !0,
      bottomNum: !1
      }) : "6" == this.data.inputOnFocusIndex ? that.setData({
        tapNum: !0,
        isNumberKB: !0,
        bottomNum :!0
    }) :that.setData({
      tapNum: !0,
      isNumberKB: !0,
      bottomNum: !1
    });
  },
  //键盘点击事件
  tapKeyboard: function (t) {
    t.target.dataset.index;
    var a = t.target.dataset.val;
    switch (this.data.inputOnFocusIndex) {
      case "0":
        this.setData({
          "inputPlates.index0": a,
          inputOnFocusIndex: "1"
        });
        break;
      case "1":
        this.setData({
          "inputPlates.index1": a,
          inputOnFocusIndex: "2"
        });
        break;
      case "2":
        this.setData({
          "inputPlates.index2": a,
          inputOnFocusIndex: "3"
        });
        break;
      case "3":
        this.setData({
          "inputPlates.index3": a,
          inputOnFocusIndex: "4"
        });
        break;
      case "4":
        this.setData({
          "inputPlates.index4": a,
          inputOnFocusIndex: "5"
        });
        break;
      case "5":
        this.setData({
          "inputPlates.index5": a,
          inputOnFocusIndex: "6"
        });
        break;
      case "6":
        this.setData({
          "inputPlates.index6": a,
          inputOnFocusIndex: ""
        });
        break;
      case "7":
        this.setData({
          "inputPlates.index7": a,
          inputOnFocusIndex: ""
        });
    }
    this.initPlate();//监听车牌实时变化
    this.checkedSubmitButtonEnabled();
    if (this.data.inputOnFocusIndex == ''){
      this.setData({
        isKeyboard: !1,
        isNumberKB: !1,
        bottomNum: !1,
        inputOnFocusIndex: ""
      });
    }
  },
  //键盘关闭按钮点击事件
  tapSpecBtn: function (t) {
    var a = this, e = t.target.dataset.index;
    if (0 == e) {
      switch (parseInt(this.data.inputOnFocusIndex)) {
        case 0:
          this.setData({
            "inputPlates.index0": "",
            inputOnFocusIndex: "0"
          });
          break;
        case 1:
          this.setData({
            "inputPlates.index1": "",
            inputOnFocusIndex: "0"
          });
          break;
        case 2:
          this.setData({
            "inputPlates.index2": "",
            inputOnFocusIndex: "1"
          });
          break;
        case 3:
          this.setData({
            "inputPlates.index3": "",
            inputOnFocusIndex: "2"
          });
          break;
        case 4:
          this.setData({
            "inputPlates.index4": "",
            inputOnFocusIndex: "3"
          });
          break;
        case 5:
          this.setData({
            "inputPlates.index5": "",
            inputOnFocusIndex: "4"
          });
          break;
        case 6:
          this.setData({
            "inputPlates.index6": "",
            inputOnFocusIndex: "5"
          });
          break;
        case 7:
          this.setData({
            "inputPlates.index7": "",
            inputOnFocusIndex: "6"
          });
      }
      this.checkedSubmitButtonEnabled();
    } else 1 == e && a.setData({
      isKeyboard: !1,
      isNumberKB: !1,
      bottomNum: !1,
      inputOnFocusIndex: ""
    });
    this.initPlate(); //监听车牌实时变化
  },
  //键盘切换
  checkedKeyboard: function () {
    var t = this;
    "0" == this.data.inputOnFocusIndex ? t.setData({
      tapNum: !1,
      isNumberKB: !1,
      bottomNum: !1
    }) : "1" == this.data.inputOnFocusIndex ? t.setData({
      tapNum: !1,
      isNumberKB: !0,
      bottomNum: !1
      }) : "6" == this.data.inputOnFocusIndex ? t.setData({
        tapNum: !0,
        isNumberKB: !0,
        bottomNum: !0
      }) :this.data.inputOnFocusIndex.length > 0 && t.setData({
      tapNum: !0,
      isNumberKB: !0,
      bottomNum: !1
    });
  },
  checkedSubmitButtonEnabled: function () {
    this.checkedKeyboard();
    var t = !0;
    for (var a in this.data.inputPlates) if ("index7" != a && this.data.inputPlates[a].length < 1) {
      t = !1;
      break;
    }
  },
  

/**
   * 弹窗组件！！！代码
   */
  onReady: function () {
    //获得popup组件
    this.popup = this.selectComponent("#popup");
  },
 
  showPopup() {
    this.popup.showPopup();
  },
 
  //取消事件
  _error() {
    console.log('你点击了取消');
    this.popup.hidePopup();
  },
  //确认事件
  _success() {
    console.log('你点击了确定');
    this.popup.hidePopup();
    wx.switchTab({

      url: '../index/index',
 
    })  
  }
})