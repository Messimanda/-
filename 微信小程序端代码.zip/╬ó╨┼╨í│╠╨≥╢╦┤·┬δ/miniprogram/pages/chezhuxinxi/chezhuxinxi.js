// pages/chezhuxinxi/chezhuxinxi.js
  /**
   * 页面的初始数据
   */
 // pages/chezhuxinxi/chezhuxinxi.js
 var app = getApp();
 Page({
   data: {
     name: '',
     call:'',
     chepai:'',
     yuyuechewei:'',
     qishi:'',
     zhongzhi:''
   },    

  btnclick:function(options){
    wx.navigateTo({
      url: '../logs/logs',
    })
  },
   //名字
   name: function(e) {
     this.setData({
       name: e.detail.value
     });
   },
   // 电话号码
   call: function(e) {
     this.setData({
       call: e.detail.value
     });
   },
    // 车牌
    chepai: function(e) {
     this.setData({
       chepai: e.detail.value
     });
   },
    // 预约车位
    yuyuechewei: function(e) {
     this.setData({
       yuyuechewei: e.detail.value
     });
   },
    // 起始
    qishi: function(e) {
     this.setData({
       qishi: e.detail.value
     });
   },
    // 终止
    zhongzhi: function(e) {
     this.setData({
       zhongzhi: e.detail.value
     });
   },
 
   onLoad: function (options) {
     if (app.globalData.openid) {
       this.setData({
         openid: app.globalData.openid
       })
     }
   },
 
   onShow: function() {
     this.setData({
       name: app.appData.account.name,
       call: app.appData.account.call,
       chepai: app.appData.account.chepai,
       yuyuechewei: app.appData.account.yuyuechewei,
       qishi: app.appData.account.qishi,
       zhongzhi: app.appData.account.zhongzhi
     })
   },
 
   ceshi: function () {
     wx.redirectTo({
       url: '../ceshi/ceshi',
     })
   },
   
   onAdd: function () {
     var name = this.data.name;
     var call = this.data.call;
     var chepai = this.data.chepai;
     var yuyuechewei = this.data.yuyuechewei;
     var qishi = this.data.qishi;
     var zhongzhi = this.data.zhongzhi;
     var that = this;
     if (call === '') {
       wx.showToast({
         title: '请输入姓名',
         icon: 'none',
         duration: 2000,
         mask: true
       });
     } else if (name === '') {
       wx.showToast({
         title: '请输入手机号',
         icon: 'none',
         duration: 2000,
         mask: true
       });
     } else if (chepai === '') {
       wx.showToast({
         title: '请输入车牌号',
         icon: 'none',
         duration: 2000,
         mask: true
       });
     } else if (yuyuechewei === '') {
       wx.showToast({
         title: '请输入出租车位',
         icon: 'none',
         duration: 2000,
         mask: true
       });
     } else if (qishi === '') {
       wx.showToast({
         title: '请输入起始时间',
         icon: 'none',
         duration: 2000,
         mask: true
       });
     } else if (zhongzhi === '') {
       wx.showToast({
         title: '请输入终止时间',
         icon: 'none',
         duration: 2000,
         mask: true
       });
     } 
     else {
       // 初始化云
       wx.cloud.init({
         env: 'test-92ce45',
         traceUser: true
       });
       // 初始化数据库
       const db = wx.cloud.database();
       db.collection('hello').add({
         // data 字段表示需新增的 JSON 数据
         data: {
          name: name,
          call: call,
          chepai:chepai,
          yuyuechewei:yuyuechewei,
          qishi:qishi,
          zhongzhi:zhongzhi
         },
         success: function(res) {
           // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
           console.log(res);
           console.log(res.errMsg);
           //wx.showToast({
            // title: '新增记录成功',
           //})
           console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
         },fail: err => {
           wx.showToast({
             icon: 'none',
             title: '新增记录失败'
           })
           console.error('[数据库] [新增记录] 失败：', err)
         }
        })
     }
     var chezhushijian = []
     for(let i=0;i<zhongzhi-qishi;i++)//假设只能连续分段，简化问题
     {
       chezhushijian[i]=(Number(qishi) + i)+"-"+(Number(qishi)+i+1)
     }

    var shijianbiaoji= []
     wx.cloud.init({
      env: 'test-92ce45'
    });
    const db = wx.cloud.database();
    const _ = db.command;
     db.collection('hello').where({
      _id: "b1a52c595fc7505a00cd385c24e5d869",
      _openid: "ohe065GnE45k-qKNMkD1e1LCQsrY",
    }).get({
      success: function (res) {
      for(let j=0;j<chezhushijian.length;j++)
      {
        for (let i = 0; i < 17; i++) 
        {
          if(chezhushijian[j] == res.data[0].rentInfo[i].time)
             shijianbiaoji[j] = i
          // console.log(res.data[0].rentInfo[i].time)
          // console.log(ceshishuju)
        }
      }
for(let i=0;i<shijianbiaoji.length;i++)
{
        if(shijianbiaoji[i]==0){
        db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              0:{
                isRent:false
              }
            }
          }
        })
      }
        else if(shijianbiaoji[i]==1)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              1:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==2)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              2:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==3)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              3:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==4)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              4:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==5)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              5:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==6)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              6:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==7)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              7:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==8)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              8:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==9)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              9:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==10)
        { db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              10:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==11)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              11:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==12)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              12:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==13)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              13:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==14)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              14:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==15)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              15:{
                isRent:false
              }
            }
          }
        })}
        else if(shijianbiaoji[i]==16)
        {db.collection('hello').doc('b1a52c595fc7505a00cd385c24e5d869').update({
          // data 传入需要局部更新的数据
          data: {
            rentInfo:{
              16:{
                isRent:false
              }
            }
          }
        })}
      }
    }
    })

    this.popup.showPopup();
   },
 
   /**
    * 生命周期函数--监听页面初次渲染完成
    */
   onReady: function () {
 
   },
 
   /**
    * 生命周期函数--监听页面显示
    */
   onShow: function () {
 
   },
 
   /**
    * 生命周期函数--监听页面隐藏
    */
   onHide: function () {
 
   },
 
   /**
    * 生命周期函数--监听页面卸载
    */
   onUnload: function () {
 
   },
 
   /**
    * 页面相关事件处理函数--监听用户下拉动作
    */
   onPullDownRefresh: function () {
 
   },
 
   /**
    * 页面上拉触底事件的处理函数
    */
   onReachBottom: function () {
 
   },
 
   /**
    * 用户点击右上角分享
    */
   onShareAppMessage: function () {
   },

   onReady: function () {
    //获得popup组件
    this.popup = this.selectComponent("#popup");
  },
 

 
  //取消事件
  _error() {
    console.log('你点击了取消');
    this.popup.hidePopup();
  },
  //确认事件
  _success() {
    console.log('你点击了确定');
    this.popup.hidePopup();
    wx.switchTab({

      url: '../index/index',
 
    })  
  }

 })