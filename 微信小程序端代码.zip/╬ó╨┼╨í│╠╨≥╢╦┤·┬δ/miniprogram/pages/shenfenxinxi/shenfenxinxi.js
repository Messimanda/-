// pages/chezhuxinxi/chezhuxinxi.js
    var app = getApp();
Page({
  data: {
    name: '',
    call:'',
    chepai:'',
    yuyuechewei:'',
    qishi:'',
    zhongzhi:''
  },    
  //名字
  name: function(e) {
    this.setData({
      name: e.detail.value
    });
  },
  // 电话号码
  call: function(e) {
    this.setData({
      call: e.detail.value
    });
  },
   // 车牌
   chepai: function(e) {
    this.setData({
      chepai: e.detail.value
    });
  },
   // 预约车位
   yuyuechewei: function(e) {
    this.setData({
      yuyuechewei: e.detail.value
    });
  },
   // 起始
  //  qishi: function(e) {
  //   this.setData({
  //     qishi: e.detail.value
  //   });
  // },
   // 终止
  //  zhongzhi: function(e) {
  //   this.setData({
  //     zhongzhi: e.detail.value
  //   });
  // },

  onLoad: function (options) {
    if (app.globalData.openid) {
      this.setData({
        openid: app.globalData.openid
      })
    }
  },

  onShow: function() {
    this.setData({
      name: app.appData.account.name,
      call: app.appData.account.call,
      chepai: app.appData.account.chepai,
      yuyuechewei: app.appData.account.yuyuechewei,
     // qishi: app.appData.account.qishi,
      //zhongzhi: app.appData.account.zhongzhi
    })
  },

  // ceshi: function () {
  //   wx.redirectTo({
  //     url: '../ceshi/ceshi',
  //   })
  // },
  
  onAdd: function () {
    var name = this.data.name;
    var call = this.data.call;
    var chepai = this.data.chepai;
    var yuyuechewei = this.data.yuyuechewei;
    //var qishi = this.data.qishi;
   // var zhongzhi = this.data.zhongzhi;
    var that = this;
    if (name === '') {
      wx.showToast({
        title: '请输入姓名',
        icon: 'none',
        duration: 2000,
        mask: true
      });
    } else if (call === '') {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none',
        duration: 2000,
        mask: true
      });
    } else if (chepai === '') {
      wx.showToast({
        title: '请输入车牌号',
        icon: 'none',
        duration: 2000,
        mask: true
      });
    } else if (yuyuechewei === '') {
      wx.showToast({
        title: '请输入预约车位',
        icon: 'none',
        duration: 2000,
        mask: true
      });
    }  
    else {
      // 初始化云
      wx.cloud.init({
        env: 'test-92ce45',
        traceUser: true
      });
      // 初始化数据库
      const db = wx.cloud.database();
      db.collection('xinxi').add({
        // data 字段表示需新增的 JSON 数据
        data: {
         name: name,
         call: call,
         chepai:chepai,
         yuyuechewei:yuyuechewei,
        // qishi:qishi,
         //zhongzhi:zhongzhi
        },
        success: function(res) {
          // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
          console.log(res);
          console.log(res.errMsg);
          //wx.showToast({
            //title: '新增记录成功',
          //})
          console.log('[数据库] [新增记录] 成功，记录 _id: ', res._id)
        },fail: err => {
          wx.showToast({
            icon: 'none',
            title: '新增记录失败'
          })
          console.error('[数据库] [新增记录] 失败：', err)
        }
       })
    }
    this.popup.showPopup();

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 弹窗组件！！！代码
   */
  onReady: function () {
    //获得popup组件
    this.popup = this.selectComponent("#popup");
  },
 

 
  //取消事件
  _error() {
    console.log('你点击了取消');
    this.popup.hidePopup();
  },
  //确认事件
  _success() {
    console.log('你点击了确定');
    this.popup.hidePopup();
    wx.switchTab({

      url: '../index/index',
 
    })  
  }
})