// pages/new/new.js
//getApp()
const app=getApp()
const devicesId = "627018347" // 填写在OneNet上获得的devicesId 形式就是一串数字 例子:9939133
const api_key = "9mdYTtoLqxHPuxluw4vK93KXTjQ=" // 填写在OneNet上的 api-key 例子: VeFI0HZ44Qn5dZO14AuLbWSlSlI=

Page({
  /**

   * 页面的初始数据

   */
  data: {
    currtab: 0,
    swipertab: [{ name: '已完成', index: 0 }, { name: '待付款', index: 1 }, { name: '已取消', index: 2 }],
    time:""
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */

  onReady: function () {
    // 页面渲染完成
    this.getDeviceInfo()
    this.orderShow()
  },

  getDeviceInfo: function () {
    let that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          deviceW: res.windowWidth,
          deviceH: res.windowHeight
        })
      }
    })
  },

  /**
  * @Explain：选项卡点击切换
  */
  tabSwitch: function (e) {
    var that = this
    if (this.data.currtab === e.target.dataset.current) {
      return false
    } else {
      that.setData({
        currtab: e.target.dataset.current
      })
    }
  },
 
  tabChange: function (e) {
    this.setData({ currtab: e.detail.current })
    this.orderShow()
  },

  orderShow: function () {
    let that = this
    switch (this.data.currtab) {
      case 0:
        that.alreadyShow()
        break
      case 1:
        that.waitPayShow()
        break
      case 2:
        that.lostShow()
        break
    }
  },

  alreadyShow: function(){
    this.setData({
      alreadyOrder: [{ name: "车库A01号", state: "交易成功", time: "2020-11-2 14:00-16:00", status: "2h已结束", url: "../image/che.jpg",money: "20" }, { name: "车库B06号", state: "交易成功", time: "2020-11-3 18:00-20:00", status: "2h已结束",url: "../image/che.jpg", money: "20" }]
    })
  },

 

  waitPayShow:function(){
    this.setData({
      waitPayOrder: [{ name: "车库B01号", state: "待付款", time: "2020-11-14 14:00-15:00", status: "正在进行", url: "../image/fukuan.png", money: "80" }],
      

    })
    this.setData({
     time: app.globalData.myselectSite,
    
    money:app.globalData.myselectSite.length
    })
   // console.log(app.globalData.myselectSite)
    //console.log(app.globalData.myselectSite.length)
  
     let string1="waitPayOrder[0].time";
      this.setData({
        [string1]:this.data.time
      })
    
    //
    for(let j=0;j<this.data.waitPayOrder.length;j++)
    {
     let string2="waitPayOrder["+j+"].money";
      this.setData({
        [string2]:this.data.money
      })
    }
  },

  lostShow: function () {
    this.setData({
      lostOrder: [{ name: "车库A01号", state: "已取消", time: "2020-11-14 13:00-14:00", status: "未开始",url: "../image/che.jpg", money: "10" }],

    })
  },

  huichuan: function () {
    wx.request({
      url: 'http://api.heclouds.com/devices/627018347/datastreams/car_out', //设备API地址 改成carout！
      data: {  
      },
      header: {
          'content-type': 'application/json', // http头部
          'api-key': api_key
      },
      success: function(res) {
        console.log(res.data.data.current_value) //可以看到返回的json格式数据
        let chepai = res.data.data.current_value;
        // 初始化云
        wx.cloud.init({
          env: 'test-92ce45',
          traceUser: true
        });
        // 初始化数据库
        const db = wx.cloud.database();
        const _ = db.command;
        db.collection('xinxi').where({//三处数据库集合名字
          chepai: chepai
        }).get({
          success: function (res) {
            if (res.data.length == 1){
            console.log("找到了！！");
            var that=this
            let deviceid = "627018347"
            let apikey = "9mdYTtoLqxHPuxluw4vK93KXTjQ="
            let data={
           "datastreams": [
               {"id": "temp","datapoints":[{"value": 1}]
               }
                    ]
                     }

          wx.request({
          url: "http://api.heclouds.com/devices/627018347/datapoints",
          method:'POST',
          header:{
          "content-type": 'application/json',
          "api-key": apikey
          },
          data:JSON.stringify(data),
          success(res){
          console.log("更新数据成功",res)
          },
          fail: function(res){
          wx.showToast({ title: '系统错误' })
          },
          complete:function(res){
          wx.hideLoading()
            }
          })
          }
          else{console.log("找不到");}
            }
          }
        )

        //更改车位锁控制信息 让其上升 上升为0
        db.collection('xinxi').where({
          chepai: chepai
        }).get({
          success: function (res) {
            if (res.data.length == 1){
              let yuyuechewei=res.data[0].yuyuechewei
              let id = res.data[0]._id//id删除了

              console.log(res.data)
              console.log(yuyuechewei)
            console.log("找到了！！！！！");
            var that=this
            let deviceid = "627018347"
            let apikey = "9mdYTtoLqxHPuxluw4vK93KXTjQ="
            let data={
           "datastreams": [
               {
                "id": yuyuechewei,"datapoints":[{"value": 0}]//车位锁0上升
              }
                    ]
                     }
          wx.request({
          url: "http://api.heclouds.com/devices/627018347/datapoints",
          method:'POST',
          header:{
          "content-type": 'application/json',
          "api-key": apikey
          },
          data:JSON.stringify(data),
          success(res){
          console.log("更新数据成功",res)
          db.collection('xinxi').doc(id).remove()
          },
          
          fail: function(res){
          wx.showToast({ title: '系统错误' })
          },
          complete:function(res){
          wx.hideLoading()
            }
          })
          }
          else{console.log("找不到");}
            }
          }
        )

          },
      //检查数据库
      checkboxChange: function() {
      },
    })
    
      wx.navigateTo({
        url: '../fukuan/fukuan',
      })
    
  },
  
})